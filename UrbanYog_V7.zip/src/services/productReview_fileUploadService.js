const productReview_fileUploadModel = require("../models").product_review_file_upload

class product_review_file_uploadService{
    getFiles(id){
        console.log("from serviede: ", id)
        return productReview_fileUploadModel.findAndCountAll({
            where: {
                review_id: id
            }
        })
    }

    store_uploads(data){
        console.log(data)
        return productReview_fileUploadModel.bulkCreate(data)
    }
}


module.exports = product_review_file_uploadService